# CSS Masterclass

CSS Masterclass course (Flexbox, Grid, PostCSS, CSSNext)

### CSS Flex

- [x] CSS Flex Basics
- [x] Main Axis and Cross Axis
- [x] Flex Direction
- [x] Flex Wrap
- [x] Align Self

### CSS Grid

- [x] CSS Grid Basics ( Row, columns and gaps)
- [x] Auto columns, auto rows
- [x] Template Areas
- [x] fr unit, repeat
- [x] minmax, max-content, min-content
- [x] auto-fill, auto-fit
- [x] Justify Content, Align Content and Place Content
- [x] Justify Items, Align Items and Place Items
- [x] Grid Column, Column Start and End
- [x] Line Naming
- [x] Grid Row, Row Start and End
- [x] Grid Area
- [x] Justify, Align, Place Self

### Using CSS4

- [x] Installing Parcel
- [x] Configuring PostCSS
- [x] Testing

### CSS4 Awesomeness

- [x] :matches , :not
- [x] CSS Variables
- [x] @custom-selector
- [x] @custom-media
- [x] Media Query Ranges
- [x] color-mod, gray(), system-ui
- [x] Nesting Rules

### Conclusions

- [x] CSS Grid Kiss
- [x] Practice Flexbox
- [x] Practice Grid

### Exercices

<img src="https://i.pinimg.com/originals/7d/4c/66/7d4c66d0b646478a297ee21e7cd8aee5.jpg" width="300px" />
<img src="https://i.pinimg.com/originals/c3/64/72/c36472e703f1ca49324f53991f610392.jpg" width="300px" />
<img src="https://i.pinimg.com/originals/69/63/a5/6963a5c312b1994e1c7ea094bbd508de.jpg" width="300px" />
<img src="https://i.pinimg.com/564x/af/c5/fd/afc5fdee8a4036487d89ae08da9f1745.jpg" width="300px" />
<img src="https://i.pinimg.com/564x/ba/ea/9d/baea9d5be82afaaea4aa6a739a0cc6a8.jpg" width="300px" />
<img src="https://i.pinimg.com/564x/fd/90/23/fd9023163c117b63caac113a7bd47f5c.jpg" width="300px" />

<img src="https://i.pinimg.com/564x/a4/0d/ba/a40dba0269d7de0120496ec830d6b25a.jpg" width="300px" />
<img src="https://cdn.dribbble.com/users/102267/screenshots/4275407/afisha_by_radiusss.jpg" width="300px" />
